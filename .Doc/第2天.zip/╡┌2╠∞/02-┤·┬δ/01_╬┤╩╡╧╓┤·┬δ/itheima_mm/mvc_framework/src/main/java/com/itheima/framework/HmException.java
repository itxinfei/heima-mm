package com.itheima.framework;

/**
 * @author ：seanyang
 * @date ：Created in 2019/8/9
 * @description ：自定义异常类
 * @version: 1.0
 */
public class HmException extends Exception {
	public HmException(String message){
		super(message);
	}
}
