package com.itheima.framework;

/**
 * @author ：seanyang
 * @date ：Created in 2019/8/9
 * @description ：常量信息类
 * @version: 1.0
 */
public class HmConst {
	public static final String HM_APPLICATION_CONTEXT = "HmApplicationContext";
	public static final String HM_APPLICATION_CONFIG_LOCATION = "HmContextConfigLocation";
	public static final String HM_XML_COMPONENT_SCAN_TAG = "component-scan";
	public static final String HM_XML_SCOMPONENT_SCAN_ATTR = "package";
}
